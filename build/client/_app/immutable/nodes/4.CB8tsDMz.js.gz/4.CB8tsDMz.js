import{s}from"../chunks/scheduler.Bmg8oFKD.js";import{S as t,i as e}from"../chunks/index.B9evkK4s.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
