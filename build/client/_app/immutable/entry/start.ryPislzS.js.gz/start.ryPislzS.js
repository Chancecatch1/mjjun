import{a as t}from"../chunks/entry.D_8yT8mQ.js";export{t as start};
