import{a as t}from"../chunks/entry.DlH8fFA_.js";export{t as start};
